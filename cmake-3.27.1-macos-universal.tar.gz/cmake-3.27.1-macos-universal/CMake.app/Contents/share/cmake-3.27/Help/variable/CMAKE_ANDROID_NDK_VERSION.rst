CMAKE_ANDROID_NDK_VERSION
-------------------------

.. versionadded:: 3.20

When :ref:`Cross Compiling for Android with the NDK` and using an
Android NDK version 11 or higher, this variable is provided by
CMake to report the NDK version number.
